<?php

namespace App\Livewire\Documents;

use App\Models\Document;
use App\Support\AuditLogger;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;
use Livewire\WithFileUploads;

class Form extends Component
{
    use WithFileUploads;

    public ?Document $document = null;

    public string $series_number = '';
    public string $title = '';
    public string $document_type = 'Ordinance';
    public string $subject_matter = '';
    public string $sponsor = '';
    public string $status = 'Filed';
    public string $date_filed = '';
    public ?string $date_approved_mayor = null;
    public $scannedFile = null;
    public ?string $existingFilePath = null;

    public const STATUSES = [
        'Filed', 'Under Committee Review', 'For Plenary Deliberation',
        'Approved', 'Vetoed', 'Returned', 'Enacted', 'Archived',
    ];

    public function mount(?Document $document = null): void
    {
        abort_unless(Auth::user()->isAdmin() || Auth::user()->isEncoder(), 403);

        if ($document?->exists) {
            $this->document = $document;
            $this->series_number = $document->series_number;
            $this->title = $document->title;
            $this->document_type = $document->document_type;
            $this->subject_matter = $document->subject_matter ?? '';
            $this->sponsor = $document->sponsor;
            $this->status = $document->status;
            $this->date_filed = $document->date_filed->format('Y-m-d');
            $this->date_approved_mayor = $document->date_approved_mayor?->format('Y-m-d');
            $this->existingFilePath = $document->file_path;
        }
    }

    public function removeExistingFile(): void
    {
        $this->existingFilePath = null;
    }

    public function save(): void
    {
        $validated = $this->validate([
            'series_number' => 'required|string|max:50',
            'title' => 'required|string|max:255',
            'document_type' => 'required|in:Ordinance,Resolution',
            'subject_matter' => 'nullable|string|max:255',
            'sponsor' => 'required|string|max:150',
            'status' => 'required|in:' . implode(',', self::STATUSES),
            'date_filed' => 'required|date',
            'date_approved_mayor' => 'nullable|date',
            'scannedFile' => 'nullable|file|mimes:pdf,jpg,jpeg,png|max:15360',
        ]);

        unset($validated['scannedFile']);

        if ($this->scannedFile) {
            $validated['file_path'] = $this->scannedFile->store('documents', 'public');
            $validated['file_hash'] = hash_file('sha256', $this->scannedFile->getRealPath());
        } elseif ($this->document && $this->existingFilePath === null) {
            $validated['file_path'] = null;
            $validated['file_hash'] = null;
        }

        if ($this->document) {
            $this->document->update($validated);
            AuditLogger::log('Updated document ' . $this->document->series_number, $this->document->document_id);
        } else {
            $validated['encoded_by'] = Auth::id();
            $document = Document::create($validated);
            AuditLogger::log('Encoded document ' . $document->series_number, $document->document_id);
        }

        session()->flash('success', 'Document saved successfully.');
        $this->redirect(route('documents.index'), navigate: true);
    }
}

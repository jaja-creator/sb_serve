<?php

namespace App\Livewire\Documents;

use App\Models\Amendment;
use App\Models\CommitteeReport;
use App\Models\Document;
use App\Models\DocumentLink;
use App\Models\Ordinance;
use App\Models\Resolution;
use App\Models\StatusHistory;
use App\Support\AuditLogger;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;
use Livewire\WithFileUploads;

class Show extends Component
{
    use WithFileUploads;

    public Document $document;

    // Ordinance/Resolution inline form fields
    public bool $showStageForm = false;
    public string $stage = 'Draft';
    public string $version_number = '1.0';
    public string $author = '';
    public string $committee_referred = '';
    public string $purpose = '';
    public string $date_prepared = '';
    public string $implementing_agency = '';
    public string $target_beneficiaries = '';
    public string $remarks = '';

    // Status change
    public bool $showStatusForm = false;
    public string $newStatus = '';
    public string $statusRemarks = '';

    // Committee Report
    public bool $showReportForm = false;
    public string $committee_name = '';
    public string $report_title = '';
    public string $report_date = '';
    public string $recommendation = 'For Approval';
    public string $findings = '';

    public const RECOMMENDATIONS = ['For Approval', 'For Amendment', 'For Rejection', 'For Further Study'];

    // Amendment
    public bool $showAmendmentForm = false;
    public string $section_amended = '';
    public string $amendment_description = '';
    public string $amendment_date = '';

    public const AMENDMENT_STATUSES = ['Pending', 'Approved', 'Rejected'];

    // Document Link
    public bool $showLinkForm = false;
    public string $link_type = 'Related Ordinance';
    public string $reference_title = '';
    public string $reference_number = '';
    public string $source_url = '';
    public $referenceFile = null;

    public const LINK_TYPES = ['Related Ordinance', 'Related Resolution', 'Legal Basis', 'Supporting Document', 'Other'];

    public function mount(Document $document): void
    {
        $this->document = $document->load([
            'encoder', 'ordinance', 'resolution',
            'committeeReports.preparer', 'amendments.submitter', 'amendments.reviewer',
            'statusHistory.changer', 'links.adder',
        ]);

        $this->newStatus = $document->status;
        $this->author = Auth::user()->name;
        $this->date_prepared = now()->format('Y-m-d');
        $this->report_date = now()->format('Y-m-d');
        $this->amendment_date = now()->format('Y-m-d');
    }

    public function verifyFileIntegrity(): void
    {
        if (! $this->document->file_path || ! $this->document->file_hash) {
            session()->flash('error', 'No file or hash on record to verify.');
            return;
        }

        $fullPath = storage_path('app/public/' . $this->document->file_path);

        if (! file_exists($fullPath)) {
            session()->flash('error', 'File is missing from storage.');
            return;
        }

        $currentHash = hash_file('sha256', $fullPath);

        if ($currentHash === $this->document->file_hash) {
            session()->flash('success', 'File integrity verified — no changes detected since upload.');
        } else {
            session()->flash('error', 'WARNING: File hash mismatch. This file may have been altered since upload.');
        }
    }

    public function saveOrdinance(): void
    {
        abort_unless(Auth::user()->isAdmin() || Auth::user()->isEncoder(), 403);

        $validated = $this->validate([
            'stage' => 'required|string|max:20',
            'version_number' => 'required|string|max:20',
            'author' => 'required|string|max:150',
            'committee_referred' => 'nullable|string|max:150',
            'date_prepared' => 'required|date',
            'implementing_agency' => 'nullable|string|max:150',
            'target_beneficiaries' => 'nullable|string|max:255',
            'remarks' => 'nullable|string',
        ]);

        $validated['document_id'] = $this->document->document_id;
        $validated['encoded_by'] = Auth::id();

        Ordinance::create($validated);

        $this->document->refresh()->load('ordinance');
        $this->showStageForm = false;
        session()->flash('success', 'Ordinance details added.');
    }

    public function saveResolution(): void
    {
        abort_unless(Auth::user()->isAdmin() || Auth::user()->isEncoder(), 403);

        $validated = $this->validate([
            'stage' => 'required|string|max:20',
            'version_number' => 'required|string|max:20',
            'author' => 'required|string|max:150',
            'purpose' => 'nullable|string|max:255',
            'date_prepared' => 'required|date',
            'implementing_agency' => 'nullable|string|max:150',
            'target_beneficiaries' => 'nullable|string|max:255',
            'remarks' => 'nullable|string',
        ]);

        $validated['document_id'] = $this->document->document_id;
        $validated['encoded_by'] = Auth::id();

        Resolution::create($validated);

        $this->document->refresh()->load('resolution');
        $this->showStageForm = false;
        session()->flash('success', 'Resolution details added.');
    }

    public function changeStatus(): void
    {
        abort_unless(Auth::user()->isAdmin() || Auth::user()->isEncoder(), 403);

        $this->validate([
            'newStatus' => 'required|in:' . implode(',', Form::STATUSES),
            'statusRemarks' => 'nullable|string',
        ]);

        $oldStatus = $this->document->status;

        StatusHistory::create([
            'document_id' => $this->document->document_id,
            'old_status' => $oldStatus,
            'new_status' => $this->newStatus,
            'remarks' => $this->statusRemarks,
            'changed_by' => Auth::id(),
        ]);

        $this->document->update(['status' => $this->newStatus]);
        AuditLogger::log("Changed status from {$oldStatus} to {$this->newStatus}", $this->document->document_id);
        $this->document->refresh()->load('statusHistory.changer');

        $this->showStatusForm = false;
        $this->statusRemarks = '';
        session()->flash('success', 'Status updated successfully.');
    }

    public function saveCommitteeReport(): void
    {
        abort_unless(Auth::user()->isAdmin() || Auth::user()->isEncoder(), 403);

        $validated = $this->validate([
            'committee_name' => 'required|string|max:150',
            'report_title' => 'required|string|max:255',
            'report_date' => 'required|date',
            'recommendation' => 'required|in:' . implode(',', self::RECOMMENDATIONS),
            'findings' => 'nullable|string',
        ]);

        $validated['document_id'] = $this->document->document_id;
        $validated['prepared_by'] = Auth::id();

        CommitteeReport::create($validated);

        $this->document->refresh()->load('committeeReports.preparer');

        $this->reset(['committee_name', 'report_title', 'findings', 'showReportForm']);
        $this->report_date = now()->format('Y-m-d');
        $this->recommendation = 'For Approval';

        session()->flash('success', 'Committee report added.');
    }

public function saveAmendment(): void
    {
        abort_unless(Auth::user()->isAdmin(), 403);

        $validated = $this->validate([
            'section_amended' => 'required|string|max:100',
            'amendment_description' => 'required|string',
            'amendment_date' => 'required|date',
        ]);

        $validated['document_id'] = $this->document->document_id;
        $validated['amendment_status'] = 'Pending';
        $validated['submitted_by'] = Auth::id();

        Amendment::create($validated);

        $this->document->refresh()->load('amendments.submitter', 'amendments.reviewer');

        $this->reset(['section_amended', 'amendment_description', 'showAmendmentForm']);
        $this->amendment_date = now()->format('Y-m-d');

        session()->flash('success', 'Amendment submitted for review.');
    }

    public function reviewAmendment(int $amendmentId, string $decision): void
    {
        abort_unless(Auth::user()->isAdmin(), 403);

        $amendment = Amendment::findOrFail($amendmentId);
        $amendment->update([
            'amendment_status' => $decision,
            'reviewed_by' => Auth::id(),
        ]);

        $this->document->refresh()->load('amendments.submitter', 'amendments.reviewer');

        session()->flash('success', "Amendment {$decision}.");
    }

    public function saveLink(): void
    {
        abort_unless(Auth::user()->isAdmin() || Auth::user()->isEncoder(), 403);

        $validated = $this->validate([
            'link_type' => 'required|in:' . implode(',', self::LINK_TYPES),
            'reference_title' => 'required|string|max:255',
            'reference_number' => 'nullable|string|max:100',
            'source_url' => 'nullable|url|max:500',
            'referenceFile' => 'nullable|file|mimes:pdf,doc,docx,jpg,jpeg,png|max:10240',
        ]);

        if (! $validated['source_url'] && ! $this->referenceFile) {
            $this->addError('source_url', 'Provide either a URL or upload a file.');
            return;
        }

        $validated['document_id'] = $this->document->document_id;
        $validated['added_by'] = Auth::id();

        if ($this->referenceFile) {
            $validated['file_path'] = $this->referenceFile->store('document-links', 'public');
        }

        DocumentLink::create($validated);

        $this->document->refresh()->load('links.adder');

        $this->reset(['reference_title', 'reference_number', 'source_url', 'referenceFile', 'showLinkForm']);
        $this->link_type = 'Related Ordinance';

        session()->flash('success', 'Reference link added.');
    }
}

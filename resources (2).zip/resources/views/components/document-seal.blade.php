@props(['status'])

@php
$colors = match($status) {
    'Enacted' => ['ring' => '#1B4332', 'fill' => '#1B4332', 'text' => '#F5F0E6'],
    'Approved' => ['ring' => '#1B4332', 'fill' => 'none', 'text' => '#1B4332'],
    'For Plenary Deliberation' => ['ring' => '#1B4332', 'fill' => 'none', 'text' => '#1B4332'],
    'Under Committee Review' => ['ring' => '#C9A227', 'fill' => 'none', 'text' => '#8A6D1A'],
    'Filed' => ['ring' => '#C9A227', 'fill' => 'none', 'text' => '#8A6D1A'],
    'Vetoed' => ['ring' => '#8B2635', 'fill' => '#8B2635', 'text' => '#F5F0E6'],
    'Returned' => ['ring' => '#8B2635', 'fill' => 'none', 'text' => '#8B2635'],
    default => ['ring' => '#6B7A75', 'fill' => 'none', 'text' => '#6B7A75'],
};
$id = 'seal-path-' . uniqid();
@endphp

<div {{ $attributes->merge(['class' => 'inline-flex items-center justify-center animate-stamp']) }}>
    <svg viewBox="0 0 120 120" width="88" height="88" style="transform: rotate(-6deg);">
        <defs>
            <path id="{{ $id }}" d="M 60,60 m -42,0 a 42,42 0 1,1 84,0 a 42,42 0 1,1 -84,0" />
        </defs>

        <circle cx="60" cy="60" r="52" fill="{{ $colors['fill'] === 'none' ? 'none' : $colors['fill'] }}" opacity="{{ $colors['fill'] === 'none' ? '0' : '0.06' }}" />
        <circle cx="60" cy="60" r="52" fill="none" stroke="{{ $colors['ring'] }}" stroke-width="2" />
        <circle cx="60" cy="60" r="44" fill="none" stroke="{{ $colors['ring'] }}" stroke-width="1" />

        <path d="M60,42 L64,54 L77,54 L66,62 L70,75 L60,67 L50,75 L54,62 L43,54 L56,54 Z"
              fill="{{ $colors['text'] }}" opacity="0.85" />

        <text font-size="10" letter-spacing="2" fill="{{ $colors['text'] }}" font-weight="600" style="text-transform: uppercase;">
            <textPath href="#{{ $id }}" startOffset="50%" text-anchor="middle">
                &#8226; {{ $status }} &#8226;
            </textPath>
        </text>
    </svg>
</div>

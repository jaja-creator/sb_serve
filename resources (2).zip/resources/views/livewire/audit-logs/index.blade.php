<div class="p-6">
    <div class="mb-6">
        <flux:heading size="lg" class="font-serif">Audit Logs</flux:heading>
        <p class="text-xs text-steel font-mono uppercase tracking-widest mt-1">System Activity Wire</p>
    </div>

    <div class="bg-white/60 rounded-lg p-4 shadow-sm mb-8 grid grid-cols-1 md:grid-cols-3 gap-4">
        <flux:input wire:model.live.debounce.400ms="search" placeholder="Search by action or user..." />
        <flux:input wire:model.live="dateFrom" type="date" label="From" />
        <flux:input wire:model.live="dateTo" type="date" label="To" />
    </div>

    <div class="log-wire">
        @forelse ($logs as $log)
            <div class="log-entry" wire:key="log-{{ $log->log_id }}">
                <div class="log-node"></div>
                <div class="log-content">
                    <div class="flex items-baseline justify-between gap-4 flex-wrap">
                        <span class="font-mono text-xs text-seal-gold font-semibold">
                            {{ $log->logged_at->format('M d, Y') }} &middot; {{ $log->logged_at->format('g:i A') }}
                        </span>
                        <span class="font-mono text-[10px] text-steel">{{ $log->ip_address }}</span>
                    </div>
                    <p class="text-sm mt-1">
                        <strong class="text-ink font-serif">{{ $log->user->name }}</strong>
                        <span class="text-ink/80">{{ $log->action }}</span>
                    </p>
                    @if ($log->document)
                        <flux:button href="{{ route('documents.show', $log->document->document_id) }}" size="sm" variant="ghost" class="mt-1 !px-0">
                            <span class="font-mono text-xs">&rarr; {{ $log->document->series_number }}</span>
                        </flux:button>
                    @endif
                </div>
            </div>
        @empty
            <div class="bg-white/60 rounded-lg p-8 shadow-sm text-center text-steel">
                No audit log entries found.
            </div>
        @endforelse
    </div>

    <div class="mt-6">{{ $logs->links() }}</div>
</div>

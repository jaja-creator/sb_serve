<div class="p-6 max-w-2xl mx-auto">
    <div class="mb-6">
        <flux:heading size="lg" class="font-serif">System Settings</flux:heading>
        <p class="text-xs text-steel font-mono uppercase tracking-widest mt-1">Configuration Charter</p>
    </div>

    @if (session('success'))
        <flux:callout variant="success" class="mb-4">{{ session('success') }}</flux:callout>
    @endif

    {{-- Charter panel --}}
    <div class="charter-panel mb-6">
        <div class="charter-seal">
            <flux:icon name="building-office-2" class="size-5" />
        </div>
        <p class="text-center text-[10px] uppercase tracking-widest text-seal-gold font-mono font-semibold mb-4">
            Registered Institution Particulars
        </p>

        <form wire:submit="save" class="space-y-4">
            <flux:input wire:model="organization_name" label="Organization Name" />
            <flux:input wire:model="municipality" label="Municipality" />
            <flux:input wire:model="contact_email" label="Contact Email (optional)" type="email" />
            <flux:input wire:model="documents_per_page" label="Documents Per Page (listings)" type="number" min="5" max="100" />

            <flux:button type="submit" variant="primary">Save Settings</flux:button>
        </form>
    </div>

    {{-- Control switch panel --}}
    <div class="switch-panel">
        <p class="text-center text-[10px] uppercase tracking-widest text-parchment/70 font-mono font-semibold mb-1">
            Master Control
        </p>
        <flux:heading size="md" class="font-serif text-parchment text-center mb-2">Maintenance Mode</flux:heading>
        <p class="text-sm text-parchment/70 text-center mb-6 max-w-sm mx-auto">
            When enabled, the system becomes inaccessible to all users except administrators.
        </p>

        <div class="flex flex-col items-center gap-4">
            <button
                wire:click="toggleMaintenance"
                wire:confirm="{{ $maintenance_mode ? 'Bring the system back online?' : 'Take the system offline for maintenance? Only administrators will be able to access it.' }}"
                class="lever-switch {{ $maintenance_mode ? 'lever-switch-on' : '' }}"
            >
                <div class="lever-knob"></div>
            </button>

            <span class="text-[10px] uppercase tracking-widest font-mono font-semibold px-3 py-1 rounded"
                  style="background-color: {{ $maintenance_mode ? 'rgba(139,38,53,0.25)' : 'rgba(201,162,39,0.25)' }}; color: {{ $maintenance_mode ? '#F3E1E3' : '#C9A227' }};">
                {{ $maintenance_mode ? 'OFFLINE — MAINTENANCE' : 'ONLINE — LIVE' }}
            </span>
        </div>
    </div>
</div>

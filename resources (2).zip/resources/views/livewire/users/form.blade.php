<div class="max-w-2xl mx-auto p-6">
    <div class="charter-panel">
        <p class="text-center text-[10px] uppercase tracking-widest text-seal-gold font-mono font-semibold mb-1">
            {{ $user ? 'Personnel Amendment' : 'New Personnel Record' }}
        </p>
        <flux:heading size="lg" class="font-serif text-center mb-6">{{ $user ? 'Edit User Account' : 'Create User Account' }}</flux:heading>

        @if ($user && $user->id === auth()->id())
            <flux:callout variant="warning" class="mb-4">
                You are editing your own account. Role cannot be changed away from Administrator.
            </flux:callout>
        @endif

        <form wire:submit="save" class="space-y-6">
            <div>
                <p class="text-[10px] uppercase tracking-widest text-ledger-green font-mono font-semibold mb-2 border-b border-seal-gold/40 pb-1">
                    I. Personal Details
                </p>
                <div class="space-y-4">
                    <flux:input wire:model="name" label="Full Name" />
                    <flux:input wire:model="username" label="Username" />
                    <flux:input wire:model="email" label="Email" type="email" />
                </div>
            </div>

            <div>
                <p class="text-[10px] uppercase tracking-widest text-ledger-green font-mono font-semibold mb-2 border-b border-seal-gold/40 pb-1">
                    II. Access Clearance
                </p>
                <div class="space-y-4">
                    <flux:select wire:model="role" label="Role" :disabled="$user && $user->id === auth()->id()">
                        <flux:select.option value="administrator">Administrator</flux:select.option>
                        <flux:select.option value="encoder">Encoder (Legislative Staff)</flux:select.option>
                        <flux:select.option value="viewer">Viewer (SB Member)</flux:select.option>
                    </flux:select>

                    <div class="flex items-center justify-between bg-white/50 rounded-lg px-4 py-3">
                        <div>
                            <p class="text-sm font-medium text-ink">Active Account</p>
                            <p class="text-xs text-steel">Account can log in when enabled</p>
                        </div>
                        <label class="mini-lever {{ $is_active ? 'mini-lever-on' : '' }} {{ ($user && $user->id === auth()->id()) ? 'opacity-50 pointer-events-none' : '' }}">
                            <input type="checkbox" wire:model="is_active" class="sr-only" @disabled($user && $user->id === auth()->id())>
                            <div class="mini-lever-knob"></div>
                        </label>
                    </div>
                </div>
            </div>

            <div>
                <p class="text-[10px] uppercase tracking-widest text-ledger-green font-mono font-semibold mb-2 border-b border-seal-gold/40 pb-1">
                    III. Credentials
                </p>
                <div class="space-y-4">
                    <flux:input wire:model="password" label="{{ $user ? 'New Password (leave blank to keep current)' : 'Password' }}" type="password" />
                    <flux:input wire:model="password_confirmation" label="Confirm Password" type="password" />
                </div>
            </div>

            <div class="flex gap-2 pt-4 border-t border-steel/20">
                <flux:button type="submit" variant="primary" wire:loading.attr="disabled" wire:target="save">
                    <span wire:loading.remove wire:target="save">Save Account</span>
                    <span wire:loading wire:target="save">Saving...</span>
                </flux:button>
                <flux:button href="{{ route('users.index') }}" variant="ghost">Cancel</flux:button>
            </div>
        </form>
    </div>
</div>

<div class="p-6">
    <div class="flex items-center justify-between mb-6">
        <div>
            <flux:heading size="lg" class="font-serif">User Accounts</flux:heading>
            <p class="text-xs text-steel font-mono uppercase tracking-widest mt-1">Personnel Roster</p>
        </div>
        <flux:button href="{{ route('users.create') }}" variant="primary" icon="plus">
            Create Account
        </flux:button>
    </div>

    @if (session('success'))
        <flux:callout variant="success" class="mb-4">{{ session('success') }}</flux:callout>
    @endif

    @if (session('error'))
        <flux:callout variant="danger" class="mb-4">{{ session('error') }}</flux:callout>
    @endif

    <div class="bg-white/60 rounded-lg p-4 shadow-sm mb-6 flex gap-4">
        <flux:input wire:model.live.debounce.400ms="search" placeholder="Search by name, username, or email..." class="flex-1" />

        <flux:select wire:model.live="roleFilter" placeholder="All Roles">
            <flux:select.option value="">All Roles</flux:select.option>
            <flux:select.option value="administrator">Administrator</flux:select.option>
            <flux:select.option value="encoder">Encoder</flux:select.option>
            <flux:select.option value="viewer">Viewer</flux:select.option>
        </flux:select>

        <flux:select wire:model.live="statusFilter" placeholder="All Statuses">
            <flux:select.option value="">All Statuses</flux:select.option>
            <flux:select.option value="active">Active</flux:select.option>
            <flux:select.option value="inactive">Inactive</flux:select.option>
        </flux:select>
    </div>

    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        @forelse ($users as $user)
            @php
                $roleColor = match($user->role) {
                    'administrator' => '#8B2635',
                    'encoder' => '#1B4332',
                    default => '#6B7A75',
                };
            @endphp
            <div class="id-badge {{ !$user->is_active ? 'id-badge-inactive' : '' }}" wire:key="user-{{ $user->id }}">
                <div class="id-badge-clip"></div>
                <div class="id-badge-lanyard" style="background-color: {{ $roleColor }};"></div>

                <div class="id-badge-body">
                    <div class="flex justify-center -mt-2 mb-3">
                        <div class="id-badge-photo" style="border-color: {{ $roleColor }};">
                            <flux:avatar :initials="$user->initials()" class="!size-full !bg-transparent !text-ink !text-xl" />
                        </div>
                    </div>

                    <div class="text-center mb-3">
                        <p class="font-serif font-semibold text-ink text-lg leading-tight">{{ $user->name }}</p>
                        @if ($user->id === auth()->id())
                            <span class="text-[9px] uppercase tracking-widest text-seal-gold font-mono">This is you</span>
                        @endif
                        <p class="font-mono text-xs text-steel mt-1">{{ $user->username }}</p>
                    </div>

                    <div class="flex justify-center gap-2 mb-3">
                        <span class="text-[10px] uppercase tracking-widest font-mono font-semibold px-2 py-0.5 rounded"
                              style="background-color: {{ $roleColor }}22; color: {{ $roleColor }};">
                            {{ ucfirst($user->role) }}
                        </span>
                        <span class="text-[10px] uppercase tracking-widest font-mono font-semibold px-2 py-0.5 rounded"
                              style="background-color: {{ $user->is_active ? '#1B433222' : '#8B263522' }}; color: {{ $user->is_active ? '#1B4332' : '#8B2635' }};">
                            {{ $user->is_active ? 'Active' : 'Inactive' }}
                        </span>
                    </div>

                    <p class="text-center text-xs text-steel truncate mb-4">{{ $user->email }}</p>

                    <div class="flex gap-2 justify-center border-t border-dashed border-steel/25 pt-3">
                        <flux:button href="{{ route('users.edit', $user->id) }}" size="sm" variant="ghost">Edit</flux:button>

                        @if ($user->id !== auth()->id())
                            <flux:button
                                wire:click="toggleActive({{ $user->id }})"
                                wire:confirm="Are you sure you want to {{ $user->is_active ? 'deactivate' : 'activate' }} this account?"
                                size="sm"
                                variant="{{ $user->is_active ? 'danger' : 'primary' }}"
                            >
                                {{ $user->is_active ? 'Deactivate' : 'Activate' }}
                            </flux:button>
                        @endif
                    </div>
                </div>
            </div>
        @empty
            <div class="col-span-full bg-white/60 rounded-lg p-8 shadow-sm text-center text-steel">
                No user accounts found.
            </div>
        @endforelse
    </div>

    <div class="mt-8">{{ $users->links() }}</div>
</div>

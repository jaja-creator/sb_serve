<div class="p-6 max-w-5xl mx-auto">
    <div class="flex items-center justify-between mb-2 print:hidden">
        <div>
            <flux:heading size="lg" class="font-serif">Alphabetical Topic Index</flux:heading>
            <p class="text-xs text-steel font-mono uppercase tracking-widest mt-1">Gazetteer of Legislative Subjects</p>
        </div>
        <flux:button onclick="window.print()" variant="ghost" icon="printer">
            Print
        </flux:button>
    </div>
    <p class="text-steel mb-6 print:hidden">
        Browse all legislative documents by topic. This page can be printed for offline reference during power or internet outages.
    </p>

    <div class="hidden print:block mb-6 border-b-2 border-ink pb-4">
        <p class="text-xs uppercase tracking-widest font-mono">Republic of the Philippines</p>
        <h1 class="text-xl font-serif font-bold">Sangguniang Bayan of Allacapan</h1>
        <p class="text-sm">Alphabetical Topic Index</p>
        <p class="text-xs text-steel font-mono mt-1">Printed {{ now()->format('F d, Y g:i A') }}</p>
    </div>

    <div class="flex gap-0 print:block">
        {{-- Thumb-index rail --}}
        <div class="thumb-index print:hidden">
            @foreach (range('A', 'Z') as $letter)
                @if ($availableLetters->contains($letter))
                    <a href="#letter-{{ $letter }}" class="thumb-tab thumb-tab-active">{{ $letter }}</a>
                @else
                    <span class="thumb-tab thumb-tab-inactive">{{ $letter }}</span>
                @endif
            @endforeach
        </div>

        {{-- Pages --}}
        <div class="gazetteer-page flex-1">
            @forelse ($groupedDocuments as $letter => $documents)
                <div id="letter-{{ $letter }}" class="mb-10 pb-8 border-b border-steel/15 last:border-0">
                    <div class="flex items-baseline gap-4 mb-4">
                        <span class="dropcap-letter">{{ $letter }}</span>
                        <span class="text-xs text-steel font-mono uppercase tracking-widest">{{ count($documents) }} {{ Str::plural('entry', count($documents)) }}</span>
                    </div>

                    <div class="pl-2">
                        @foreach ($documents as $document)
                            <a href="{{ route('documents.show', $document->document_id) }}" wire:navigate class="block py-3 border-b border-dashed border-steel/25 last:border-0 text-sm hover:bg-parchment -mx-2 px-2 rounded print:hover:bg-transparent">
                                <div class="font-medium text-ink font-serif">{{ $document->subject_matter ?: $document->title }}</div>
                                <div class="text-steel text-xs mt-0.5">
                                    <span class="font-mono">{{ $document->series_number }}</span> &middot; {{ $document->title }} &middot; {{ $document->document_type }} &middot; {{ $document->status }}
                                </div>
                            </a>
                        @endforeach
                    </div>
                </div>
            @empty
                <p class="text-sm text-steel">No documents available yet.</p>
            @endforelse
        </div>
    </div>
</div>

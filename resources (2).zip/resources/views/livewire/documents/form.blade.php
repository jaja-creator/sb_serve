<div class="max-w-2xl mx-auto p-6">
    <div class="bg-white/60 rounded-lg shadow-sm border-t-4 border-seal-gold relative overflow-hidden">
        <div class="absolute top-0 right-0 bg-ledger-green text-parchment text-[10px] font-mono uppercase tracking-widest px-3 py-1 rounded-bl-lg">
            SB-Serve Form {{ $document ? '02-A' : '01-A' }}
        </div>

        <div class="p-6">
            <p class="text-xs uppercase tracking-widest text-steel font-mono mb-1">
                {{ $document ? 'Amend Registry Entry' : 'New Registry Entry' }}
            </p>
            <flux:heading size="lg" class="font-serif mb-6">{{ $document ? 'Edit Document' : 'Encode New Document' }}</flux:heading>

            <form wire:submit="save" class="space-y-6">
                <div>
                    <p class="text-[10px] uppercase tracking-widest text-seal-gold font-mono font-semibold mb-2 border-b border-seal-gold/40 pb-1">
                        I. Identification
                    </p>
                    <div class="space-y-4">
                        <flux:input wire:model="series_number" label="Series Number" />
                        <flux:input wire:model="title" label="Title" />
                        <flux:select wire:model="document_type" label="Document Type">
                            <flux:select.option value="Ordinance">Ordinance</flux:select.option>
                            <flux:select.option value="Resolution">Resolution</flux:select.option>
                        </flux:select>
                    </div>
                </div>

                <div>
                    <p class="text-[10px] uppercase tracking-widest text-seal-gold font-mono font-semibold mb-2 border-b border-seal-gold/40 pb-1">
                        II. Particulars
                    </p>
                    <div class="space-y-4">
                        <flux:textarea wire:model="subject_matter" label="Subject Matter" />
                        <flux:input wire:model="sponsor" label="Sponsor" />
                        <flux:select wire:model="status" label="Status">
                            @foreach (\App\Livewire\Documents\Form::STATUSES as $option)
                                <flux:select.option value="{{ $option }}">{{ $option }}</flux:select.option>
                            @endforeach
                        </flux:select>
                    </div>
                </div>

                <div>
                    <p class="text-[10px] uppercase tracking-widest text-seal-gold font-mono font-semibold mb-2 border-b border-seal-gold/40 pb-1">
                        III. Dates on Record
                    </p>
                    <div class="space-y-4">
                        <flux:input wire:model="date_filed" label="Date Filed" type="date" />
                        <flux:input wire:model="date_approved_mayor" label="Date Approved by Mayor" type="date" />
                    </div>
                </div>

                <div>
                    <p class="text-[10px] uppercase tracking-widest text-seal-gold font-mono font-semibold mb-2 border-b border-seal-gold/40 pb-1">
                        IV. Supporting Attachment
                    </p>

                    <label for="scannedFile" class="photo-dropzone {{ $scannedFile || $existingFilePath ? 'photo-dropzone-filled' : '' }}">
                        @if ($scannedFile)
                            <img src="{{ $this->photoPreviewUrl }}" alt="Selected photo preview" class="photo-dropzone-preview" />
                        @elseif ($existingFilePath)
                            <img src="{{ asset('storage/' . $existingFilePath) }}" alt="Current attachment" class="photo-dropzone-preview" />
                        @else
                            <flux:icon name="camera" class="size-6 text-steel" />
                            <span class="text-sm text-steel mt-2">Click to add a picture of the document</span>
                            <span class="text-xs text-steel/70 mt-0.5">JPG, PNG, or WEBP &middot; up to 15MB</span>
                        @endif

                        <input id="scannedFile" type="file" accept="image/*" wire:model="scannedFile" class="sr-only" />
                    </label>

                    <div wire:loading wire:target="scannedFile" class="text-xs text-steel mt-2">Uploading photo...</div>

                    @error('scannedFile') <p class="text-xs text-seal-red mt-2">{{ $message }}</p> @enderror

                    @if ($scannedFile || $existingFilePath)
                        <div class="flex items-center gap-3 mt-2">
                            @if ($scannedFile)
                                <span class="text-xs text-steel truncate">{{ $scannedFile->getClientOriginalName() }}</span>
                            @elseif ($existingFilePath)
                                <a href="{{ asset('storage/' . $existingFilePath) }}" target="_blank" class="text-xs text-ledger-green underline">
                                    View full size
                                </a>
                            @endif
                            <flux:button wire:click="removeExistingFile" size="sm" variant="ghost" class="ml-auto">Remove</flux:button>
                        </div>
                    @endif
                </div>

                <div class="flex flex-wrap items-center gap-2 pt-4 border-t border-steel/20">
                    <flux:button type="submit" variant="primary" wire:loading.attr="disabled" wire:target="save,saveDraft">
                        <span wire:loading.remove wire:target="save">Save Document</span>
                        <span wire:loading wire:target="save">Saving...</span>
                    </flux:button>

                    <flux:button
                        type="button"
                        wire:click="saveDraft"
                        variant="filled"
                        wire:loading.attr="disabled"
                        wire:target="save,saveDraft"
                    >
                        <span wire:loading.remove wire:target="saveDraft">Save as Draft</span>
                        <span wire:loading wire:target="saveDraft">Saving draft...</span>
                    </flux:button>

                    <flux:button href="{{ route('documents.index') }}" variant="ghost" class="ml-auto">Cancel</flux:button>
                </div>
            </form>
        </div>
    </div>
</div>

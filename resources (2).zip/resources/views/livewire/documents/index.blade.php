<div class="p-6">
    <div class="flex items-center justify-between mb-6">
        <div>
            <flux:heading size="lg" class="font-serif">Legislative Documents</flux:heading>
            <p class="text-xs text-steel font-mono uppercase tracking-widest mt-1">Registry &middot; {{ $documents->total() }} record(s) on file</p>
        </div>

        @if (auth()->user()->isAdmin() || auth()->user()->isEncoder())
            <flux:button href="{{ route('documents.create') }}" variant="primary" icon="plus">
                Encode Document
            </flux:button>
        @endif
    </div>

    @if (session('success'))
        <flux:callout variant="success" class="mb-4">
            {{ session('success') }}
        </flux:callout>
    @endif

    <div class="bg-white/60 rounded-lg p-4 shadow-sm mb-6 flex gap-4">
        <flux:input wire:model.live.debounce.400ms="search" placeholder="Search by title, series number, or sponsor..." icon="magnifying-glass" class="flex-1" />

        <flux:select wire:model.live="statusFilter" placeholder="All Statuses">
            <flux:select.option value="">All Statuses</flux:select.option>
            @foreach (\App\Livewire\Documents\Form::STATUSES as $status)
                <flux:select.option value="{{ $status }}">{{ $status }}</flux:select.option>
            @endforeach
        </flux:select>
    </div>

    <div class="bg-white/60 rounded-lg shadow-sm overflow-hidden mb-6">
        <flux:table>
            <flux:table.columns>
                <flux:table.column>Document</flux:table.column>
                <flux:table.column>Sponsor</flux:table.column>
                <flux:table.column>Status</flux:table.column>
                <flux:table.column>Date Filed</flux:table.column>
                <flux:table.column class="w-10"></flux:table.column>
            </flux:table.columns>

            <flux:table.rows>
                @forelse ($documents as $document)
                    <flux:table.row wire:key="document-{{ $document->document_id }}">
                        <flux:table.cell>
                            <a href="{{ route('documents.show', $document->document_id) }}" wire:navigate class="block">
                                <div class="font-serif font-medium text-ink leading-snug">{{ $document->title }}</div>
                                <div class="text-xs text-steel font-mono mt-0.5">{{ $document->document_type }} &middot; {{ $document->series_number }}</div>
                            </a>
                        </flux:table.cell>

                        <flux:table.cell class="text-sm text-ink/80">{{ $document->sponsor }}</flux:table.cell>

                        <flux:table.cell>
                            <x-status-pill :status="$document->status" />
                        </flux:table.cell>

                        <flux:table.cell class="text-xs text-steel font-mono whitespace-nowrap">
                            {{ $document->date_filed->format('M d, Y') }}
                        </flux:table.cell>

                        <flux:table.cell>
                            <flux:dropdown position="bottom" align="end">
                                <flux:button icon="ellipsis-horizontal" variant="ghost" size="sm" aria-label="Row actions" />

                                <flux:menu>
                                    <flux:menu.item icon="eye" href="{{ route('documents.show', $document->document_id) }}" wire:navigate>
                                        View
                                    </flux:menu.item>

                                    @if (auth()->user()->isAdmin() || auth()->user()->isEncoder())
                                        <flux:menu.item icon="pencil" href="{{ route('documents.edit', $document->document_id) }}" wire:navigate>
                                            Edit
                                        </flux:menu.item>
                                    @endif

                                    @if (auth()->user()->canDelete())
                                        <flux:menu.separator />
                                        <flux:menu.item
                                            icon="trash"
                                            variant="danger"
                                            wire:click="deleteDocument({{ $document->document_id }})"
                                            wire:confirm="Are you sure you want to delete this document?"
                                        >
                                            Delete
                                        </flux:menu.item>
                                    @endif
                                </flux:menu>
                            </flux:dropdown>
                        </flux:table.cell>
                    </flux:table.row>
                @empty
                    <flux:table.row>
                        <flux:table.cell colspan="5" class="text-center text-steel py-10">
                            No documents found in the registry.
                        </flux:table.cell>
                    </flux:table.row>
                @endforelse
            </flux:table.rows>
        </flux:table>
    </div>

    <div class="mt-4">
        {{ $documents->links() }}
    </div>
</div>

<div class="p-6 max-w-4xl mx-auto">
    @if (session('success'))
        <flux:callout variant="success" class="mb-4">
            {{ session('success') }}
        </flux:callout>
    @endif

    @if (session('error'))
        <flux:callout variant="danger" class="mb-4">
            {{ session('error') }}
        </flux:callout>
    @endif

    {{-- Hero: Title + Seal --}}
    <div class="bg-white/60 rounded-lg p-6 shadow-sm mb-6 flex items-start justify-between gap-6">
        <div>
            <p class="text-xs uppercase tracking-widest text-steel font-mono mb-1">{{ $document->document_type }} &middot; {{ $document->series_number }}</p>
            <flux:heading size="xl" class="font-serif leading-tight [&::first-letter]:text-5xl [&::first-letter]:font-bold [&::first-letter]:text-seal-gold [&::first-letter]:mr-1 [&::first-letter]:float-left">{{ $document->title }}</flux:heading>
        </div>
        <x-document-seal :status="$document->status" class="shrink-0" />
    </div>

    <div class="bg-white/60 rounded-lg p-4 shadow-sm grid grid-cols-2 gap-4 mb-6 text-sm">
        <div><span class="text-steel">Sponsor:</span> <span class="text-ink">{{ $document->sponsor }}</span></div>
        <div><span class="text-steel">Date Filed:</span> <span class="text-ink">{{ $document->date_filed->format('M d, Y') }}</span></div>
        <div><span class="text-steel">Encoded by:</span> <span class="text-ink">{{ $document->encoder->name }}</span></div>
        <div><span class="text-steel">Subject Matter:</span> <span class="text-ink">{{ $document->subject_matter ?? '—' }}</span></div>
        <div class="col-span-2">
            <span class="text-steel">Scanned Copy:</span>
            @if ($document->file_path)
                <a href="{{ asset('storage/' . $document->file_path) }}" target="_blank" class="text-ledger-green underline">View / Download</a>
                <flux:button wire:click="verifyFileIntegrity" size="sm" variant="ghost">Verify Integrity</flux:button>
                @if ($document->file_hash)
                    <div class="text-xs text-steel font-mono mt-1">SHA-256: {{ Str::limit($document->file_hash, 24) }}...</div>
                @endif
            @else
                <span class="text-steel/60">Not uploaded</span>
            @endif
        </div>
    </div>

    @if (auth()->user()->isAdmin() || auth()->user()->isEncoder())
        <div class="mb-6 bg-white/60 rounded-lg p-4 shadow-sm">
            @if (! $showStatusForm)
                <flux:button wire:click="$set('showStatusForm', true)" variant="ghost" size="sm">
                    Change Status
                </flux:button>
            @else
                <div class="space-y-3 max-w-md">
                    <flux:select wire:model="newStatus" label="New Status">
                        @foreach (\App\Livewire\Documents\Form::STATUSES as $status)
                            <flux:select.option value="{{ $status }}">{{ $status }}</flux:select.option>
                        @endforeach
                    </flux:select>
                    <flux:textarea wire:model="statusRemarks" label="Remarks (optional)" />
                    <div class="flex gap-2">
                        <flux:button wire:click="changeStatus" variant="primary" size="sm" wire:loading.attr="disabled" wire:target="changeStatus">
                            <span wire:loading.remove wire:target="changeStatus">Confirm</span>
                            <span wire:loading wire:target="changeStatus">Updating...</span>
                        </flux:button>
                        <flux:button wire:click="$set('showStatusForm', false)" variant="ghost" size="sm">Cancel</flux:button>
                    </div>
                </div>
            @endif
        </div>
    @endif

    <div class="mb-6 bg-white/60 rounded-lg p-4 shadow-sm">
        <flux:heading size="md" class="mb-3 font-serif">
            {{ $document->document_type }} Details
        </flux:heading>

        @if ($document->document_type === 'Ordinance')
            @if ($document->ordinance)
                <div class="text-sm space-y-1">
                    <div><span class="text-steel">Stage:</span> <span class="text-ink">{{ $document->ordinance->stage }}</span></div>
                    <div><span class="text-steel">Version:</span> <span class="font-mono text-ink">{{ $document->ordinance->version_number }}</span></div>
                    <div><span class="text-steel">Author:</span> <span class="text-ink">{{ $document->ordinance->author }}</span></div>
                    <div><span class="text-steel">Committee Referred:</span> <span class="text-ink">{{ $document->ordinance->committee_referred ?? '—' }}</span></div>
                    <div><span class="text-steel">Date Prepared:</span> <span class="text-ink">{{ $document->ordinance->date_prepared->format('M d, Y') }}</span></div>
                </div>
            @elseif (auth()->user()->isAdmin() || auth()->user()->isEncoder())
                @if (! $showStageForm)
                    <flux:button wire:click="$set('showStageForm', true)" variant="primary" size="sm">
                        Add Ordinance Details
                    </flux:button>
                @else
                    <form wire:submit="saveOrdinance" class="space-y-3 max-w-md">
                        <flux:select wire:model="stage" label="Stage">
                            <flux:select.option value="Draft">Draft</flux:select.option>
                            <flux:select.option value="Committee Review">Committee Review</flux:select.option>
                            <flux:select.option value="Final">Final</flux:select.option>
                        </flux:select>
                        <flux:input wire:model="version_number" label="Version Number" />
                        <flux:input wire:model="author" label="Author" />
                        <flux:input wire:model="committee_referred" label="Committee Referred" />
                        <flux:input wire:model="date_prepared" label="Date Prepared" type="date" />
                        <flux:input wire:model="implementing_agency" label="Implementing Agency" />
                        <flux:input wire:model="target_beneficiaries" label="Target Beneficiaries" />
                        <flux:textarea wire:model="remarks" label="Remarks" />
                        <div class="flex gap-2">
                            <flux:button type="submit" variant="primary" size="sm">Save</flux:button>
                            <flux:button wire:click="$set('showStageForm', false)" variant="ghost" size="sm">Cancel</flux:button>
                        </div>
                    </form>
                @endif
            @endif
        @elseif ($document->document_type === 'Resolution')
            @if ($document->resolution)
                <div class="text-sm space-y-1">
                    <div><span class="text-steel">Stage:</span> <span class="text-ink">{{ $document->resolution->stage }}</span></div>
                    <div><span class="text-steel">Version:</span> <span class="font-mono text-ink">{{ $document->resolution->version_number }}</span></div>
                    <div><span class="text-steel">Author:</span> <span class="text-ink">{{ $document->resolution->author }}</span></div>
                    <div><span class="text-steel">Purpose:</span> <span class="text-ink">{{ $document->resolution->purpose ?? '—' }}</span></div>
                    <div><span class="text-steel">Date Prepared:</span> <span class="text-ink">{{ $document->resolution->date_prepared->format('M d, Y') }}</span></div>
                </div>
            @elseif (auth()->user()->isAdmin() || auth()->user()->isEncoder())
                @if (! $showStageForm)
                    <flux:button wire:click="$set('showStageForm', true)" variant="primary" size="sm">
                        Add Resolution Details
                    </flux:button>
                @else
                    <form wire:submit="saveResolution" class="space-y-3 max-w-md">
                        <flux:select wire:model="stage" label="Stage">
                            <flux:select.option value="Draft">Draft</flux:select.option>
                            <flux:select.option value="Committee Review">Committee Review</flux:select.option>
                            <flux:select.option value="Final">Final</flux:select.option>
                        </flux:select>
                        <flux:input wire:model="version_number" label="Version Number" />
                        <flux:input wire:model="author" label="Author" />
                        <flux:input wire:model="purpose" label="Purpose" />
                        <flux:input wire:model="date_prepared" label="Date Prepared" type="date" />
                        <flux:input wire:model="implementing_agency" label="Implementing Agency" />
                        <flux:input wire:model="target_beneficiaries" label="Target Beneficiaries" />
                        <flux:textarea wire:model="remarks" label="Remarks" />
                        <div class="flex gap-2">
                            <flux:button type="submit" variant="primary" size="sm">Save</flux:button>
                            <flux:button wire:click="$set('showStageForm', false)" variant="ghost" size="sm">Cancel</flux:button>
                        </div>
                    </form>
                @endif
            @endif
        @endif
    </div>

    {{-- Committee Reports --}}
    <div class="mb-6 bg-white/60 rounded-lg p-4 shadow-sm">
        <div class="flex items-center justify-between mb-3">
            <flux:heading size="md" class="font-serif">Committee Reports</flux:heading>
            @if (auth()->user()->isAdmin() || auth()->user()->isEncoder())
                @if (! $showReportForm)
                    <flux:button wire:click="$set('showReportForm', true)" variant="primary" size="sm">
                        Add Committee Report
                    </flux:button>
                @endif
            @endif
        </div>

        @if ($showReportForm)
            <form wire:submit="saveCommitteeReport" class="space-y-3 max-w-md mb-4">
                <flux:input wire:model="committee_name" label="Committee Name" />
                <flux:input wire:model="report_title" label="Report Title" />
                <flux:input wire:model="report_date" label="Report Date" type="date" />
                <flux:select wire:model="recommendation" label="Recommendation">
                    @foreach (\App\Livewire\Documents\Show::RECOMMENDATIONS as $option)
                        <flux:select.option value="{{ $option }}">{{ $option }}</flux:select.option>
                    @endforeach
                </flux:select>
                <flux:textarea wire:model="findings" label="Findings" />
                <div class="flex gap-2">
                    <flux:button type="submit" variant="primary" size="sm">Save Report</flux:button>
                    <flux:button wire:click="$set('showReportForm', false)" variant="ghost" size="sm">Cancel</flux:button>
                </div>
            </form>
        @endif

        @forelse ($document->committeeReports as $report)
            <div class="text-sm py-3 border-b border-steel/20 last:border-0">
                <div class="font-medium text-ink">{{ $report->report_title }}</div>
                <div class="text-steel">{{ $report->committee_name }} &middot; {{ $report->report_date->format('M d, Y') }}</div>
                <div><flux:badge>{{ $report->recommendation }}</flux:badge></div>
                @if ($report->findings)
                    <div class="text-ink/80 mt-1">{{ $report->findings }}</div>
                @endif
                <div class="text-steel text-xs mt-1">Prepared by {{ $report->preparer->name }}</div>
            </div>
        @empty
            <p class="text-sm text-steel">No committee reports yet.</p>
        @endforelse
    </div>

    {{-- Amendments --}}
    <div class="mb-6 bg-white/60 rounded-lg p-4 shadow-sm">
        <div class="flex items-center justify-between mb-3">
    <flux:heading size="md" class="font-serif">Amendments</flux:heading>
    @if (auth()->user()->isAdmin())
        @if (! $showAmendmentForm)
            <flux:button wire:click="$set('showAmendmentForm', true)" variant="primary" size="sm">
                Submit Amendment
            </flux:button>
        @endif
    @endif
</div>

        @if ($showAmendmentForm)
            <form wire:submit="saveAmendment" class="space-y-3 max-w-md mb-4">
                <flux:input wire:model="section_amended" label="Section Amended" />
                <flux:textarea wire:model="amendment_description" label="Amendment Description" />
                <flux:input wire:model="amendment_date" label="Amendment Date" type="date" />
                <div class="flex gap-2">
                    <flux:button type="submit" variant="primary" size="sm">Submit</flux:button>
                    <flux:button wire:click="$set('showAmendmentForm', false)" variant="ghost" size="sm">Cancel</flux:button>
                </div>
            </form>
        @endif

        @forelse ($document->amendments as $amendment)
            <div class="text-sm py-3 border-b border-steel/20 last:border-0">
                <div class="flex items-center gap-2">
                    <span class="font-medium text-ink">Section: {{ $amendment->section_amended }}</span>
                    <flux:badge>{{ $amendment->amendment_status }}</flux:badge>
                </div>
                <div class="text-ink/80 mt-1">{{ $amendment->amendment_description }}</div>
                <div class="text-steel text-xs mt-1">
                    Submitted by {{ $amendment->submitter->name }} on {{ $amendment->amendment_date->format('M d, Y') }}
                    @if ($amendment->reviewer)
                        &middot; Reviewed by {{ $amendment->reviewer->name }}
                    @endif
                </div>

                @if (auth()->user()->isAdmin() && $amendment->amendment_status === 'Pending')
                    <div class="flex gap-2 mt-2">
                        <flux:button
                            wire:click="reviewAmendment({{ $amendment->amendment_id }}, 'Approved')"
                            wire:loading.attr="disabled"
                            wire:target="reviewAmendment({{ $amendment->amendment_id }}, 'Approved')"
                            variant="primary"
                            size="sm"
                        >
                            Approve
                        </flux:button>
                        <flux:button
                            wire:click="reviewAmendment({{ $amendment->amendment_id }}, 'Rejected')"
                            wire:loading.attr="disabled"
                            wire:target="reviewAmendment({{ $amendment->amendment_id }}, 'Rejected')"
                            variant="danger"
                            size="sm"
                        >
                            Reject
                        </flux:button>
                    </div>
                @endif
            </div>
        @empty
            <p class="text-sm text-steel">No amendments submitted yet.</p>
        @endforelse
    </div>

    {{-- Document Links --}}
    <div class="mb-6 bg-white/60 rounded-lg p-4 shadow-sm">
        <div class="flex items-center justify-between mb-3">
            <flux:heading size="md" class="font-serif">Related References</flux:heading>
            @if (auth()->user()->isAdmin() || auth()->user()->isEncoder())
                @if (! $showLinkForm)
                    <flux:button wire:click="$set('showLinkForm', true)" variant="primary" size="sm">
                        Add Reference
                    </flux:button>
                @endif
            @endif
        </div>

        @if ($showLinkForm)
            <form wire:submit="saveLink" class="space-y-3 max-w-md mb-4">
                <flux:select wire:model="link_type" label="Reference Type">
                    @foreach (\App\Livewire\Documents\Show::LINK_TYPES as $type)
                        <flux:select.option value="{{ $type }}">{{ $type }}</flux:select.option>
                    @endforeach
                </flux:select>
                <flux:input wire:model="reference_title" label="Reference Title" />
                <flux:input wire:model="reference_number" label="Reference Number (optional)" />

                <flux:input wire:model="source_url" label="Source URL (optional)" placeholder="https://..." />

                <div class="text-center text-sm text-steel">— or —</div>

                <flux:input type="file" wire:model="referenceFile" label="Upload File (PDF, Word, or Image, optional)" />
                @if ($referenceFile)
                    <p class="text-xs text-steel">Selected: {{ $referenceFile->getClientOriginalName() }}</p>
                @endif
                <div wire:loading wire:target="referenceFile" class="text-xs text-steel">Uploading...</div>

                <div class="flex gap-2">
                    <flux:button type="submit" variant="primary" size="sm">Save</flux:button>
                    <flux:button wire:click="$set('showLinkForm', false)" variant="ghost" size="sm">Cancel</flux:button>
                </div>
            </form>
        @endif

        @forelse ($document->links as $link)
            <div class="text-sm py-2 border-b border-steel/20 last:border-0">
                <flux:badge>{{ $link->link_type }}</flux:badge>
                <span class="font-medium text-ink">{{ $link->reference_title }}</span>
                @if ($link->reference_number)
                    <span class="text-steel font-mono">({{ $link->reference_number }})</span>
                @endif
                @if ($link->source_url)
                    <a href="{{ $link->source_url }}" target="_blank" class="text-ledger-green underline text-xs ml-1">visit link</a>
                @endif
                @if ($link->file_path)
                    <a href="{{ asset('storage/' . $link->file_path) }}" target="_blank" class="text-ledger-green underline text-xs ml-1">view file</a>
                @endif
                <div class="text-steel text-xs">Added by {{ $link->adder->name }}</div>
            </div>
        @empty
            <p class="text-sm text-steel">No reference links added yet.</p>
        @endforelse
    </div>

    <div class="mb-6 bg-white/60 rounded-lg p-4 shadow-sm">
        <flux:heading size="md" class="mb-3 font-serif">Status History</flux:heading>
        @forelse ($document->statusHistory as $entry)
            <div class="text-sm py-2 border-b border-steel/20 last:border-0">
                <span class="text-steel font-mono">{{ $entry->changed_at->format('M d, Y g:i A') }}</span>
                — {{ $entry->old_status ?? 'None' }} → <strong class="text-ledger-green">{{ $entry->new_status }}</strong>
                by {{ $entry->changer->name }}
                @if ($entry->remarks)
                    <div class="text-steel italic">{{ $entry->remarks }}</div>
                @endif
            </div>
        @empty
            <p class="text-sm text-steel">No status changes recorded yet.</p>
        @endforelse
    </div>

    <flux:button href="{{ route('documents.index') }}" variant="ghost">← Back to Documents</flux:button>
</div>

<div class="p-6 max-w-3xl mx-auto">
    <div class="mb-6">
        <flux:heading size="lg" class="font-serif">Backup Management</flux:heading>
        <p class="text-xs text-steel font-mono uppercase tracking-widest mt-1">Records Vault</p>
    </div>
    <p class="text-steel mb-8">Generate and manage database backups for disaster recovery.</p>

    {{-- Vault seal button --}}
    <div class="flex flex-col items-center bg-white/60 rounded-lg p-8 shadow-sm mb-8">
        <button
            wire:click="runBackup"
            wire:loading.attr="disabled"
            class="vault-button"
        >
            <flux:icon name="circle-stack" class="size-8" />
        </button>
        <p class="font-mono text-xs uppercase tracking-widest text-ink mt-3" wire:loading.remove wire:target="runBackup">
            Press to Seal a New Backup
        </p>
        <p class="font-mono text-xs uppercase tracking-widest text-seal-gold mt-3" wire:loading wire:target="runBackup">
            Sealing Records...
        </p>

        @if (session('success'))
            <flux:callout variant="success" class="mt-4 w-full">{{ session('success') }}</flux:callout>
        @endif

        <p class="text-xs text-steel font-mono mt-4">Automated backups also run daily via the system scheduler.</p>
    </div>

    {{-- Deposit ledger --}}
    <div class="mb-3">
        <p class="text-[10px] uppercase tracking-widest text-seal-gold font-mono font-semibold border-b border-seal-gold/40 pb-1">
            Vault Deposit Register
        </p>
    </div>

    <div class="space-y-3">
        @forelse ($backupHistory as $i => $backup)
            <div class="deposit-slip">
                <div class="deposit-slip-number">{{ str_pad(count($backupHistory) - $i, 3, '0', STR_PAD_LEFT) }}</div>
                <div class="flex-1 min-w-0">
                    <p class="font-mono text-sm text-ink truncate">{{ $backup['name'] }}</p>
                    <p class="text-xs text-steel font-mono">{{ $backup['date'] }} &middot; {{ $backup['size'] }}</p>
                </div>
                <div class="flex gap-2 shrink-0">
                    <flux:button wire:click="downloadBackup('{{ $backup['name'] }}')" size="sm" variant="ghost">Retrieve</flux:button>
                    <flux:button
                        wire:click="deleteBackup('{{ $backup['name'] }}')"
                        wire:confirm="Delete this backup file permanently?"
                        size="sm"
                        variant="danger"
                    >
                        Discard
                    </flux:button>
                </div>
            </div>
        @empty
            <div class="bg-white/60 rounded-lg p-8 shadow-sm text-center text-steel">
                No backups have been deposited yet.
            </div>
        @endforelse
    </div>
</div>

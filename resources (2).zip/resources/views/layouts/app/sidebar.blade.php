<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        @include('partials.head')
    </head>
    <body class="min-h-screen antialiased" style="background-color: #1B4332; background-image: radial-gradient(#C9A227 0.6px, transparent 0.6px); background-size: 22px 22px;">
        <div class="flex min-h-screen">
            {{-- Folder Tab Rail --}}
            <div class="w-20 lg:w-24 shrink-0 flex flex-col items-center pt-6 gap-1 relative z-20">
                <a href="{{ route('dashboard') }}" wire:navigate class="mb-6">
                    <span class="flex h-12 w-12 items-center justify-center rounded-full bg-seal-gold border-2 border-parchment/30 shadow-lg">
                        <x-app-logo-icon class="size-6 fill-current text-ink" />
                    </span>
                </a>

                @php
                    $tabs = [
                        ['route' => 'dashboard', 'match' => 'dashboard', 'icon' => 'home', 'label' => 'Dashboard'],
                        ['route' => 'documents.index', 'match' => 'documents.*', 'icon' => 'folder-git-2', 'label' => 'Documents'],
                        ['route' => 'reports.search', 'match' => 'reports.*', 'icon' => 'magnifying-glass', 'label' => 'Reports'],
                        ['route' => 'topic-index', 'match' => 'topic-index', 'icon' => 'book-open', 'label' => 'Index'],
                    ];
                    if (auth()->user()->isAdmin()) {
                        $tabs[] = ['route' => 'users.index', 'match' => 'users.*', 'icon' => 'users', 'label' => 'Users'];
                        $tabs[] = ['route' => 'audit-logs.index', 'match' => 'audit-logs.*', 'icon' => 'clipboard-document-list', 'label' => 'Logs'];
                        $tabs[] = ['route' => 'backup.index', 'match' => 'backup.*', 'icon' => 'circle-stack', 'label' => 'Backup'];
                        $tabs[] = ['route' => 'settings.system', 'match' => 'settings.system', 'icon' => 'cog-6-tooth', 'label' => 'Settings'];
                    }
                @endphp

                @foreach ($tabs as $i => $tab)
                    @php $isCurrent = request()->routeIs($tab['match']); @endphp
                    
                        <a href="{{ route($tab['route']) }}"
                        wire:navigate
                        class="folder-tab group w-full flex flex-col items-center justify-center py-3 transition-all duration-200 {{ $isCurrent ? 'is-active' : '' }}"
                        style="margin-right: {{ $isCurrent ? '0' : '10px' }};"
                    >
                        <flux:icon :name="$tab['icon']" class="size-5 {{ $isCurrent ? 'text-ink' : 'text-parchment/70 group-hover:text-parchment' }}" />
                        <span class="text-[9px] uppercase tracking-wider mt-1 font-mono {{ $isCurrent ? 'text-ink' : 'text-parchment/60 group-hover:text-parchment' }}">
                            {{ $tab['label'] }}
                        </span>
                    </a>
                @endforeach

                <div class="flex-1"></div>

                <div class="pb-4">
                    <flux:dropdown position="right" align="end">
                        <button class="flex flex-col items-center gap-1">
                            <flux:avatar size="sm" :initials="auth()->user()->initials()" class="!bg-seal-gold !text-ink" />
                        </button>

                        <flux:menu>
                            <flux:menu.radio.group>
                                <div class="p-0 text-sm font-normal">
                                    <div class="flex items-center gap-2 px-1 py-1.5 text-start text-sm">
                                        <flux:avatar :name="auth()->user()->name" :initials="auth()->user()->initials()" />
                                        <div class="grid flex-1 text-start text-sm leading-tight">
                                            <flux:heading class="truncate">{{ auth()->user()->name }}</flux:heading>
                                            <flux:text class="truncate">{{ auth()->user()->email }}</flux:text>
                                        </div>
                                    </div>
                                </div>
                            </flux:menu.radio.group>

                            <flux:menu.separator />

                            <flux:menu.radio.group>
                                <flux:menu.item :href="route('profile.edit')" icon="cog" wire:navigate>
                                    {{ __('Settings') }}
                                </flux:menu.item>
                            </flux:menu.radio.group>

                            <flux:menu.separator />

                            <form method="POST" action="{{ route('logout') }}" class="w-full">
                                @csrf
                                <flux:menu.item as="button" type="submit" icon="arrow-right-start-on-rectangle" class="w-full cursor-pointer">
                                    {{ __('Log out') }}
                                </flux:menu.item>
                            </form>
                        </flux:menu>
                    </flux:dropdown>
                </div>
            </div>

            {{-- Main Content --}}
            <div class="flex-1 bg-parchment rounded-l-2xl shadow-2xl relative z-10 min-h-screen">
                {{ $slot }}
            </div>
        </div>

        @persist('toast')
            <flux:toast.group>
                <flux:toast />
            </flux:toast.group>
        @endpersist

        @fluxScripts
    </body>
</html>
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        @include('partials.head')
    </head>
    <body class="min-h-screen antialiased" style="background-color: #1B4332; background-image: radial-gradient(#C9A227 0.6px, transparent 0.6px); background-size: 22px 22px;">
        <div class="flex min-h-svh flex-col items-center justify-center gap-6 p-6 md:p-10">
            <div class="flex w-full max-w-sm flex-col gap-2">
                <a href="{{ route('home') }}" class="flex flex-col items-center gap-3 mb-4" wire:navigate>
                    <span class="flex h-16 w-16 items-center justify-center rounded-full bg-seal-gold border-2 border-parchment/40 shadow-lg">
                        <x-app-logo-icon class="size-9 fill-current text-ink" />
                    </span>
                    <span class="text-parchment font-serif text-2xl font-bold tracking-wide">SB-SERVE</span>
                    <span class="text-parchment/70 text-xs uppercase tracking-widest text-center font-mono">
                        E-Record Archiving &amp; Legislative Tracking System
                    </span>
                </a>

                <div class="bg-parchment rounded-lg shadow-2xl p-8 border-t-4 border-seal-gold">
                    <div class="flex flex-col gap-6">
                        {{ $slot }}
                    </div>
                </div>

                <p class="text-center text-parchment/50 text-xs mt-4 font-mono">
                    Sangguniang Bayan of Allacapan &middot; Authorized Personnel Only
                </p>
            </div>
        </div>

        @persist('toast')
            <flux:toast.group>
                <flux:toast />
            </flux:toast.group>
        @endpersist

        @fluxScripts
    </body>
</html>
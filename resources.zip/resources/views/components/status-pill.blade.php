@props(['status'])

@php
$colors = match($status) {
    'Enacted' => ['bg' => '#1B4332', 'text' => '#F5F0E6'],
    'Approved', 'For Plenary Deliberation' => ['bg' => '#E8EFEA', 'text' => '#1B4332'],
    'Under Committee Review', 'Filed' => ['bg' => '#F5EBCB', 'text' => '#8A6D1A'],
    'Vetoed' => ['bg' => '#8B2635', 'text' => '#F5F0E6'],
    'Returned' => ['bg' => '#F3E1E3', 'text' => '#8B2635'],
    default => ['bg' => '#E5E7E6', 'text' => '#6B7A75'],
};
@endphp

<span
    {{ $attributes->merge(['class' => 'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium tracking-wide']) }}
    style="background-color: {{ $colors['bg'] }}; color: {{ $colors['text'] }};"
>
    {{ $status }}
</span>

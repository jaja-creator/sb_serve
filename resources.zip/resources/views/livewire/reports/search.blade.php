<div class="p-6">
    <div class="flex items-center justify-between mb-6">
        <div>
            <flux:heading size="lg" class="font-serif">Reports &amp; Search</flux:heading>
            <p class="text-xs text-steel font-mono uppercase tracking-widest mt-1">Registry Lookup Desk</p>
        </div>
        <div class="flex gap-2 print:hidden">
            @if (auth()->user()->isAdmin())
                <flux:button wire:click="exportCsv" variant="ghost" icon="arrow-down-tray">
                    Export CSV
                </flux:button>
                <flux:button onclick="window.print()" variant="ghost" icon="printer">
                    Print
                </flux:button>
            @endif
        </div>
    </div>

    <div class="catalog-card print:hidden mb-8">
        <div class="catalog-card-hole"></div>
        <div class="catalog-card-hole" style="left: auto; right: 24px;"></div>
        <p class="text-[10px] uppercase tracking-widest text-seal-red font-mono font-semibold mb-3 text-center">
            &mdash; Search Index &mdash;
        </p>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <flux:input wire:model.live.debounce.400ms="search" placeholder="Title, series no., or subject..." />
            <flux:input wire:model.live.debounce.400ms="sponsorFilter" placeholder="Sponsor..." />
            <flux:select wire:model.live="typeFilter" placeholder="All Types">
                <flux:select.option value="">All Types</flux:select.option>
                <flux:select.option value="Ordinance">Ordinance</flux:select.option>
                <flux:select.option value="Resolution">Resolution</flux:select.option>
            </flux:select>
            <flux:select wire:model.live="statusFilter" placeholder="All Statuses">
                <flux:select.option value="">All Statuses</flux:select.option>
                @foreach (\App\Livewire\Documents\Form::STATUSES as $status)
                    <flux:select.option value="{{ $status }}">{{ $status }}</flux:select.option>
                @endforeach
            </flux:select>
            <flux:input wire:model.live="dateFrom" type="date" label="Filed From" />
            <flux:input wire:model.live="dateTo" type="date" label="Filed To" />
        </div>
        <div class="text-center mt-4">
            <flux:button wire:click="resetFilters" variant="ghost" size="sm">Clear Index</flux:button>
        </div>
    </div>

    <div class="hidden print:block mb-6 border-b-2 border-ink pb-4">
        <p class="text-xs uppercase tracking-widest font-mono">Republic of the Philippines</p>
        <h1 class="text-xl font-serif font-bold">Sangguniang Bayan of Allacapan</h1>
        <p class="text-sm">Legislative Document Report</p>
        <p class="text-xs text-steel font-mono mt-1">Generated {{ now()->format('F d, Y g:i A') }}</p>
    </div>

    <div class="printout-slip print:bg-transparent print:shadow-none">
        <div class="printout-perforation"></div>
        <div class="p-4 font-mono text-xs text-steel uppercase tracking-widest border-b border-dashed border-steel/30 mb-2">
            Query Result &middot; {{ $documents->total() }} record(s)
        </div>

        <flux:table>
            <flux:table.columns>
                <flux:table.column>Series No.</flux:table.column>
                <flux:table.column>Title</flux:table.column>
                <flux:table.column>Type</flux:table.column>
                <flux:table.column>Sponsor</flux:table.column>
                <flux:table.column>Status</flux:table.column>
                <flux:table.column>Date Filed</flux:table.column>
            </flux:table.columns>

            <flux:table.rows>
                @forelse ($documents as $document)
                    <flux:table.row wire:key="report-{{ $document->document_id }}">
                        <flux:table.cell class="font-mono text-ink">{{ $document->series_number }}</flux:table.cell>
                        <flux:table.cell class="text-ink font-medium">{{ $document->title }}</flux:table.cell>
                        <flux:table.cell class="text-steel">{{ $document->document_type }}</flux:table.cell>
                        <flux:table.cell class="text-ink">{{ $document->sponsor }}</flux:table.cell>
                        <flux:table.cell>
                            <span class="print:hidden"><x-status-pill :status="$document->status" /></span>
                            <span class="hidden print:inline">{{ $document->status }}</span>
                        </flux:table.cell>
                        <flux:table.cell class="text-steel">{{ $document->date_filed->format('M d, Y') }}</flux:table.cell>
                    </flux:table.row>
                @empty
                    <flux:table.row>
                        <flux:table.cell colspan="6" class="text-center text-steel">No documents match your filters.</flux:table.cell>
                    </flux:table.row>
                @endforelse
            </flux:table.rows>
        </flux:table>

        <div class="mt-4 print:hidden px-4 pb-4">
            {{ $documents->links() }}
        </div>
    </div>
</div>

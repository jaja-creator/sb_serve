<div class="p-6">
    <div class="flex items-center justify-between mb-6">
        <div>
            <flux:heading size="lg" class="font-serif">Legislative Documents</flux:heading>
            <p class="text-xs text-steel font-mono uppercase tracking-widest mt-1">Registry &middot; {{ $documents->total() }} record(s) on file</p>
        </div>

        @if (auth()->user()->isAdmin() || auth()->user()->isEncoder())
            <flux:button href="{{ route('documents.create') }}" variant="primary" icon="plus">
                Encode Document
            </flux:button>
        @endif
    </div>

    @if (session('success'))
        <flux:callout variant="success" class="mb-4">
            {{ session('success') }}
        </flux:callout>
    @endif

    <div class="bg-white/60 rounded-lg p-4 shadow-sm mb-6 flex gap-4">
        <flux:input wire:model.live.debounce.400ms="search" placeholder="Search by title, series number, or sponsor..." class="flex-1" />

        <flux:select wire:model.live="statusFilter" placeholder="All Statuses">
            <flux:select.option value="">All Statuses</flux:select.option>
            @foreach (\App\Livewire\Documents\Form::STATUSES as $status)
                <flux:select.option value="{{ $status }}">{{ $status }}</flux:select.option>
            @endforeach
        </flux:select>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 mb-8">
        @forelse ($documents as $i => $document)
            <div class="file-card" wire:key="document-{{ $document->document_id }}">
                <div class="file-card-tab">
                    <span class="font-mono text-[10px] uppercase tracking-widest text-parchment/90">
                        {{ $document->document_type }} &middot; {{ $document->series_number }}
                    </span>
                </div>

                <div class="file-card-body">
                    <div class="flex items-start justify-between gap-2 mb-2">
                        <flux:heading size="sm" class="font-serif leading-snug">{{ $document->title }}</flux:heading>
                        <div class="shrink-0">
                            <x-status-pill :status="$document->status" />
                        </div>
                    </div>

                    <p class="text-sm text-ink/80 mb-3">{{ $document->sponsor }}</p>

                    <div class="flex items-center justify-between text-xs text-steel font-mono border-t border-steel/15 pt-3">
                        <span>Filed {{ $document->date_filed->format('M d, Y') }}</span>
                    </div>

                    <div class="flex gap-2 mt-4 pt-3 border-t border-steel/15">
                        <flux:button href="{{ route('documents.show', $document->document_id) }}" size="sm" variant="ghost">
                            View
                        </flux:button>

                        @if (auth()->user()->isAdmin() || auth()->user()->isEncoder())
                            <flux:button href="{{ route('documents.edit', $document->document_id) }}" size="sm" variant="ghost">
                                Edit
                            </flux:button>
                        @endif

                        @if (auth()->user()->canDelete())
                            <flux:button
                                wire:click="deleteDocument({{ $document->document_id }})"
                                wire:confirm="Are you sure you want to delete this document?"
                                size="sm"
                                variant="danger"
                                class="ml-auto"
                            >
                                Delete
                            </flux:button>
                        @endif
                    </div>
                </div>
            </div>
        @empty
            <div class="col-span-full bg-white/60 rounded-lg p-8 shadow-sm text-center text-steel">
                No documents found in the registry.
            </div>
        @endforelse
    </div>

    <div class="mt-4">
        {{ $documents->links() }}
    </div>
</div>

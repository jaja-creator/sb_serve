<div class="p-6">
    <div class="ledger-book">
        <div class="ledger-spine"></div>

        {{-- Left Page --}}
        <div class="ledger-page ledger-page-left">
            <div class="mb-6">
                <p class="text-xs text-steel font-mono uppercase tracking-widest">{{ now()->format('l, F j, Y') }}</p>
                <flux:heading size="lg" class="font-serif">Welcome back, {{ auth()->user()->name }}</flux:heading>
                <p class="text-steel text-sm">{{ ucfirst(auth()->user()->role) }} &middot; Sangguniang Bayan of Allacapan</p>
            </div>

            <div class="grid grid-cols-2 gap-4 mb-6">
                <div class="pinned-note index-card animate-rise" style="animation-delay: 0ms">
                    <p class="text-xs text-steel">Total Documents</p>
                    <p class="text-3xl font-serif font-semibold text-ledger-green">{{ $totalDocuments }}</p>
                </div>
                <div class="pinned-note index-card animate-rise" style="animation-delay: 60ms">
                    <p class="text-xs text-steel">Ordinances</p>
                    <p class="text-3xl font-serif font-semibold text-ledger-green">{{ $totalOrdinances }}</p>
                </div>
                <div class="pinned-note index-card animate-rise" style="animation-delay: 120ms">
                    <p class="text-xs text-steel">Resolutions</p>
                    <p class="text-3xl font-serif font-semibold text-ledger-green">{{ $totalResolutions }}</p>
                </div>
                <div class="pinned-note index-card animate-rise" style="animation-delay: 180ms; --pin-color: #8B2635;">
                    <p class="text-xs text-steel">Pending Amendments</p>
                    <p class="text-3xl font-serif font-semibold text-seal-red">{{ $pendingAmendments }}</p>
                </div>
            </div>

            <div class="animate-rise" style="animation-delay: 240ms">
                <p class="text-[10px] uppercase tracking-widest text-seal-gold font-mono font-semibold mb-3 border-b border-seal-gold/40 pb-1">
                    Documents by Status
                </p>
                @forelse ($statusBreakdown as $status => $count)
                    <div class="flex items-center justify-between py-2 border-b border-dashed border-steel/20 last:border-0 text-sm">
                        <x-status-pill :status="$status" />
                        <span class="font-mono font-medium text-ledger-green">{{ $count }}</span>
                    </div>
                @empty
                    <p class="text-sm text-steel">No documents yet.</p>
                @endforelse
            </div>
        </div>

        {{-- Right Page --}}
        <div class="ledger-page ledger-page-right">
            <div class="animate-rise mb-6" style="animation-delay: 300ms">
                <div class="flex items-center justify-between mb-3">
                    <p class="text-[10px] uppercase tracking-widest text-seal-gold font-mono font-semibold border-b border-seal-gold/40 pb-1">
                        Recently Filed
                    </p>
                    <flux:button href="{{ route('documents.index') }}" size="sm" variant="ghost">View All</flux:button>
                </div>
                @forelse ($recentDocuments as $doc)
                    <a href="{{ route('documents.show', $doc->document_id) }}" wire:navigate class="block py-2 border-b border-dashed border-steel/20 last:border-0 text-sm hover:bg-parchment -mx-1 px-1 rounded transition-colors">
                        <div class="font-medium text-ink font-serif">{{ $doc->title }}</div>
                        <div class="text-steel text-xs">
                            <span class="font-mono">{{ $doc->series_number }}</span> &middot; {{ $doc->date_filed->format('M d, Y') }} &middot; by {{ $doc->encoder->name }}
                        </div>
                    </a>
                @empty
                    <p class="text-sm text-steel">No documents filed yet.</p>
                @endforelse
            </div>

            @if (auth()->user()->isAdmin())
                <div class="animate-rise" style="animation-delay: 360ms">
                    <div class="flex items-center justify-between mb-3">
                        <p class="text-[10px] uppercase tracking-widest text-seal-gold font-mono font-semibold border-b border-seal-gold/40 pb-1">
                            Recent Activity
                        </p>
                        <flux:button href="{{ route('audit-logs.index') }}" size="sm" variant="ghost">View All</flux:button>
                    </div>
                    @forelse ($recentActivity as $log)
                        <div class="py-2 border-b border-dashed border-steel/20 last:border-0 text-sm">
                            <span class="text-steel text-xs font-mono">{{ $log->logged_at->diffForHumans() }}</span>
                            <div><strong class="text-ink">{{ $log->user->name }}</strong> {{ $log->action }}</div>
                        </div>
                    @empty
                        <p class="text-sm text-steel">No activity recorded yet.</p>
                    @endforelse
                </div>
            @endif
        </div>
    </div>
</div>
